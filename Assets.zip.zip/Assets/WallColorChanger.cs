using UnityEngine;

public class WallColorChanger : MonoBehaviour
{
    public GameObject[] walls;
    public GameObject[] sofas;

    Color defaultWallColor = Color.white;
    Color defaultSofaColor = new Color(0.8f, 0.5f, 0.3f);

    public void ChangeWallColor()
    {
        Color randomColor = Random.ColorHSV();

        foreach (GameObject wall in walls)
        {
            wall.GetComponent<Renderer>().material.color = randomColor;
        }

        foreach (GameObject sofa in sofas)
        {
            sofa.GetComponent<Renderer>().material.color = Random.ColorHSV();
        }
    }

    public void ResetRoom()
    {
        foreach (GameObject wall in walls)
        {
            wall.GetComponent<Renderer>().material.color = defaultWallColor;
        }

        foreach (GameObject sofa in sofas)
        {
            sofa.GetComponent<Renderer>().material.color = defaultSofaColor;
        }
    }
}